import Cart from '@/features/Cart/Cart'

export default function page () {
  return <Cart />
}
