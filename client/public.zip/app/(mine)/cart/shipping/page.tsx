import Shipping from '@/features/Cart/Shipping/Shipping'

export default function page () {
  return <Shipping />
}
