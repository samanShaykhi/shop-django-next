import ContactUs from '@/features/contactUs/ContactUs'

export default function page () {
  return <ContactUs />
}
