import Wishlist from "@/features/Wishlist/Wishlist";

export default function page () {
  return <Wishlist />
}
